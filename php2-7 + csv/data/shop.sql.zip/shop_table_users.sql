
-- --------------------------------------------------------

--
-- Структура таблицы `users`
--
-- Создание: Окт 17 2020 г., 09:29
-- Последнее обновление: Окт 17 2020 г., 09:29
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `groups_id` int(11) DEFAULT NULL,
  `login` varchar(32) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `name` varchar(32) DEFAULT NULL,
  `surname` varchar(32) DEFAULT NULL,
  `email` varchar(64) DEFAULT NULL,
  `phone` varchar(64) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `groups_id`, `login`, `password`, `name`, `surname`, `email`, `phone`, `description`) VALUES
(1, 1, 'admin', '123', NULL, NULL, NULL, NULL, NULL);
