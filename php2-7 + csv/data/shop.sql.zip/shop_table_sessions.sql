
-- --------------------------------------------------------

--
-- Структура таблицы `sessions`
--
-- Создание: Окт 17 2020 г., 09:29
-- Последнее обновление: Окт 17 2020 г., 09:29
--

CREATE TABLE `sessions` (
  `sid` varchar(64) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `last_update` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `sessions`
--

INSERT INTO `sessions` (`sid`, `user_id`, `last_update`) VALUES
('YsXs8kwpqa', 1, '2017-11-13 20:55:06'),
('5iLBGtE77Q', 1, '2017-11-13 22:51:42'),
('utWAbrkayy', 1, '2017-11-13 22:51:58');
