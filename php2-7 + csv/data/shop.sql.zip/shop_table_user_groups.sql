
-- --------------------------------------------------------

--
-- Структура таблицы `user_groups`
--
-- Создание: Окт 17 2020 г., 09:29
--

CREATE TABLE `user_groups` (
  `id` int(11) NOT NULL,
  `name` varchar(64) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
